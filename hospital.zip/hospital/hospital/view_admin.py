from rest_framework.decorators import api_view
from .Action import Action
from .models import *
from .serializers import *
from django.shortcuts import render


@api_view(['GET', "POST"])
# Administrator login
def adminLogin(request):
    # Get parameter
    name = request.POST.get('name')
    password = request.POST.get('password')
    # Query by name
    user = admin.objects.filter(name=name).first()
    if not user:
        # If the user does not exist, an error message is returned
        return Action.fail("User does not exist")
    if user.password != password:
        # If the user exists and the password is different, an error message is returned
        return Action.fail("Password error")
    # Successful landing
    return Action.success(AdminSerializer(user, many=False).data)
