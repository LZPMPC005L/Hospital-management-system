from django.shortcuts import render


# Page rendering
# Landing page
def login(request):
    return render(request, 'login.html')


# Administrator page: Department management
def admin_department(request):
    return render(request, 'admin_department.html')


# Admin page: Doctor Management
def admin_doctor(request):
    return render(request, 'admin_doctor.html')


# Admin page: Drug Management
def admin_medicine(request):
    return render(request, 'admin_medicine.html')


# Admin page: Patient Management
def admin_patient(request):
    return render(request, 'admin_patient.html')


# Patient page: Lobby
def patient_home(request):
    return render(request, 'patient_home.html')


# Patient page: Visit records
def patient_order(request):
    return render(request, 'patient_order.html')


# Doctor's page: Reception room
def doctor_home(request):
    return render(request, 'doctor_home.html')


# Doctor's page: Admission records
def doctor_order(request):
    return render(request, 'doctor_order.html')
