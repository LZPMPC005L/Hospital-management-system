from rest_framework.decorators import api_view
from .Action import Action
from .models import *
from .serializers import *


@api_view(['GET', "POST"])
# Patient registration
def patientRegister(request):
    # Get parameter
    name = request.POST.get('name')
    id_card = request.POST.get('id_card')
    phone = request.POST.get('phone')
    password = request.POST.get('password')
    sex = request.POST.get('sex')
    age = request.POST.get('age')
    # Check whether the ID number has been registered
    sameIdCardUserList = user_patient.objects.filter(id_card=id_card)
    if sameIdCardUserList.exists() == True:
        # If it is already registered, an error message is returned
        return Action.fail("You have registered")
    # If not registered, add to the database
    user = user_patient(name=name, id_card=id_card, phone=phone, password=password, sex=sex, age=age)
    user.save()
    return Action.success()


@api_view(['GET', "POST"])
# Patient login
def patientLogin(request):
    # Get parameter
    id_card = request.POST.get('name')
    password = request.POST.get('password')
    # Check by ID number
    user = user_patient.objects.filter(id_card=id_card).first()
    if not user:
        # If the user does not exist, an error message is returned
        return Action.fail("User does not exist")
    if user.password != password:
        # If the user exists and the password is different, an error message is returned
        return Action.fail("Password error")
    # Successful landing
    return Action.success(UserPatientSerializer(user, many=False).data)


@api_view(['GET', "POST"])
# Patient list
def patientList(request):
    return Action.success(UserPatientSerializer(user_patient.objects.all(), many=True).data)
