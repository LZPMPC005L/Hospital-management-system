from rest_framework.decorators import api_view
from .Action import Action
from .models import *
from .serializers import *
from django.shortcuts import render


@api_view(['GET', "POST"])
# Get department list
def departmentList(request):
    # Get parameter
    list = department.objects.all()
    for item in list:
        item.doctor_num = user_doctor.objects.filter(department_id=item.id).count()
    # Successful landing
    return Action.success(DepartmentSerializer(list, many=True).data)
    # return Action.success(list)
