from django.db import models


# Administrator
class admin(models.Model):
    id = models.AutoField(primary_key=True)  # The id is automatically created and can be manually written
    name = models.CharField(max_length=45)
    password = models.CharField(max_length=45)

    class Meta:
        db_table = 'admin'


# patient
class user_patient(models.Model):
    sex_choices = (
        (0, "Female"),
        (1, "Male")
    )
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=45)
    id_card = models.CharField(max_length=45)
    phone = models.CharField(max_length=45)
    password = models.CharField(max_length=45)
    sex = models.SmallIntegerField(choices=sex_choices)
    age = models.SmallIntegerField()

    class Meta:
        db_table = 'user_patient'


# doctor
class user_doctor(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=45)
    id_card = models.CharField(max_length=45)
    department_id = models.SmallIntegerField()
    password = models.CharField(max_length=45)
    status = models.SmallIntegerField(default=1)  # status

    class Meta:
        db_table = 'user_doctor'


# department
class department(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=45)  # Department name
    registration_fee = models.DecimalField(max_digits=10, decimal_places=2)  # Registration fee
    doctor_num = models.SmallIntegerField(default=0)  # Number of doctors

    class Meta:
        db_table = 'department'


# medicine
class medicine(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=45)
    price = models.DecimalField(max_digits=10, decimal_places=2)  # Unit price
    unit = models.CharField(max_length=45)  # number

    class Meta:
        db_table = 'medicine'


# registration order
class order(models.Model):
    id = models.AutoField(primary_key=True)
    patient_id = models.SmallIntegerField()  # Patient id
    department_id = models.SmallIntegerField()
    readme = models.CharField(max_length=200)  # Narrate in one's own words
    registration_fee = models.DecimalField(max_digits=10, decimal_places=2)
    doctor_id = models.SmallIntegerField()
    order_advice = models.CharField(max_length=400)  # Prescription
    medicine_list = models.CharField(max_length=400)  # Drug list
    total_cost = models.DecimalField(max_digits=10, decimal_places=2, default=0)  # total_cost
    status = models.SmallIntegerField(default=1)  # status
    time = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'order'
