function PageMap(index) {
    let mp={
        "1":['Library information management'],
        "2":['Warehouse management'],
        "3":['Order review'],
        "4":['Book purchase'],
        "5":['Invoice management'],
        "6":['Classified management'],
    }

    return mp[index];
}
