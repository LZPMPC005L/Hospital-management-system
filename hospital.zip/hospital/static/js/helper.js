let BaseUrl="http://127.0.0.1:8000/"
function ToDJ(relativeUrl) {
    return BaseUrl+relativeUrl
}
